#import <Flutter/Flutter.h>

@interface AudioplayerPlugin : NSObject<FlutterPlugin>
@end
