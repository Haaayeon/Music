#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/rxlabz/dev/tools/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/rxlabz/dev/projects/audioplayer2/audioplayer/audioplayer"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_FRAMEWORK_DIR=/Users/rxlabz/dev/tools/flutter/bin/cache/artifacts/engine/darwin-x64"
export "FLUTTER_BUILD_NAME=0.6.0"
export "FLUTTER_BUILD_NUMBER=0.6.0"
