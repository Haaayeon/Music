//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import audioplayer

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  AudioplayerPlugin.register(with: registry.registrar(forPlugin: "AudioplayerPlugin"))
}
