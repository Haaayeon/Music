#import <FlutterMacOS/FlutterMacOS.h>

@interface AudioplayerPlugin : NSObject <FlutterPlugin>
@end
